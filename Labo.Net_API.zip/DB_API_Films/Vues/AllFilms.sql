﻿CREATE VIEW [dbo].[AllFilms]

As

SELECT f.Titre,CONCAT(p.Nom,' ', p.Prenom) AS 'Realisateur', CONCAT(p1.Nom,' ', p1.Prenom) AS 'Scenariste'
FROM Films f JOIN Personnes p ON f.RealisateurID = p.Id
			 JOIN Personnes p1 ON f.ScenaristeID = p1.Id


