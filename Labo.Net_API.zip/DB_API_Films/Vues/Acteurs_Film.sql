﻿CREATE VIEW [dbo].[Acteurs_Film]
AS
SELECT Nom,Prenom FROM Personnes p
		JOIN Acteurs a ON p.Id = a.personneID	
