﻿CREATE VIEW [dbo].[V_Utilisateur]
	AS 
	SELECT [Id],[Email],[Administrateur],[Actif] ,[DatedeNaissance] FROM [Utilisateurs]
