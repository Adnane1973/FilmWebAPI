﻿/*
Modèle de script de post-déploiement							
--------------------------------------------------------------------------------------
 Ce fichier contient des instructions SQL qui seront ajoutées au script de compilation.		
 Utilisez la syntaxe SQLCMD pour inclure un fichier dans le script de post-déploiement.			
 Exemple :      :r .\monfichier.sql								
 Utilisez la syntaxe SQLCMD pour référencer une variable dans le script de post-déploiement.		
 Exemple :      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

-- Ajouter des Personnages
EXEC [dbo].[AjouterPersonne] 'Vin','Diesel'
EXEC [dbo].[AjouterPersonne] 'Paul','Walker'
EXEC [dbo].[AjouterPersonne] 'Michelle','Rdriguez'
EXEC [dbo].[AjouterPersonne] 'Jordana','Brewster'
EXEC [dbo].[AjouterPersonne] 'Lucas','Black'
EXEC [dbo].[AjouterPersonne] 'Rob','Cohen'
EXEC [dbo].[AjouterPersonne] 'Gary','Scott Thompson'
EXEC [dbo].[AjouterPersonne] 'Jhon','Singleton'
EXEC [dbo].[AjouterPersonne] 'Michael','Brandt'
EXEC [dbo].[AjouterPersonne] 'Justin','lin'
EXEC [dbo].[AjouterPersonne] 'Chris','Morgan'

-- Ajouter Les films
EXEC [dbo].[AjouterFilm] 'Fast and Furious',2001,'La nuit tombée, Dominic Toretto règne sur les rues de Los Angeles à la tête dune équipe de fidèles qui partagent son goût du risque, sa passion de la vitesse et son culte des voitures de sport lancées à plus de 250 km/h dans des rodéos urbains d une rare violence. Ses journées sont consacrées à bricoler et à relooker des modèles haut de gamme, à les rendre toujours plus performants et plus voyants, et à organiser des joutes illicites.',6,5
EXEC [dbo].[AjouterFilm] '2 Fast 2 Furious',2003,'Après avoir laissé s échapper le fugitif Dominic Toretto, l ancien officier de police Brian O Conner est maintenant lui aussi en cavale et quitte Los Angeles pour Miami afin de commencer une nouvelle vie. Mais une nuit, il est pris par les agents des douanes. Le FBI lui offre une dernière chance : s il accepte de prendre part à une opération conjointe des douanes et du FBI, son passé criminel sera effacé.',8,7
EXEC [dbo].[AjouterFilm] 'Fast and Furious: Tokyo Drift',2006,'Sean Boswell est un passionné de courses automobiles ayant eu plusieurs ennuis avec la police californienne. Pour éviter la prison, il doit se rendre chez son père, militaire basé à Tokyo. Sean se sent exclu des autres élèves jusqu’à ce qu il rencontre Twinkie, un passionné comme lui, qui lui fait découvrir le drift, un sport issu du milieu automobile clandestin, où l audace, l élégance et la fluidité sont plus importants que la vitesse. Malheureusement, Sean va faire la rencontre de DK (« Drift King »), le tenant du titre, qui est bien décidé à conserver son titre, quitte à utiliser des méthodes peu éthiques. Pour Sean, ce n est dès lors plus un amusement, mais bel et bien une véritable course..',10,9
--Ajouter des acteurs et leurs roles
EXEC [dbo].[AjouterActeur] 1,1,' Dominic Toretto'
EXEC [dbo].[AjouterActeur] 2,1,'Brian O Conner'
EXEC [dbo].[AjouterActeur] 3,1,' Letty Ortiz'
EXEC [dbo].[AjouterActeur] 4,1,' Mia Toretto'
EXEC [dbo].[AjouterActeur] 1,2,' Dominic Toretto'
EXEC [dbo].[AjouterActeur] 2,2,'Brian O Conner'
EXEC [dbo].[AjouterActeur] 1,3,' Dominic Toretto'
EXEC [dbo].[AjouterActeur] 2,3,'Brian O Conner'
EXEC [dbo].[AjouterActeur] 5,3,'Sean Boswell'

-- Ajouter des Utilisateurs

EXEC [dbo].[AjouterUtilisateur] 'b.picsou@outlook.com','Test1234=','1973-04-05',1,1
EXEC [dbo].[AjouterUtilisateur] 'abdeddeim@outlook.com','Test1234=#@','1944-08-15',0,1
EXEC [dbo].[AjouterUtilisateur] 'test@test.com','Azerty=#@','1982-02-09',0,1

--Ajouter des commentaires

EXEC [dbo].[AjouterCommentaire] '2021-03-26','Super la classe , c est trop de la balle',3,1
EXEC [dbo].[AjouterCommentaire] '2021-03-26','I love this Movie OMG',2,1
EXEC [dbo].[AjouterCommentaire] '2021-03-26', 'J adore la bagnole de Dom',1,1



