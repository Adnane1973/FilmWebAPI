﻿CREATE PROCEDURE [dbo].[AjouterUtilisateur]
	@Email Nvarchar(250),
	@MotDePasse nvarchar(50),
	@DateDeNaissance nvarchar(50),
	@administrateur bit,
	@actif bit
AS
BEGIN
	SET NOCOUNT ON;

	-- Generation du Salt
	DECLARE @Salt NVARCHAR(100);
	SET @Salt = CONCAT(NEWID(),NEWID(),NEWID());

	-- Recuperation de la valeur secrete
	DECLARE @Secret NVARCHAR(50);
	SET @Secret = [dbo].[GetSecretKey]();

	-- Hashage du mot de passe avec le salt
	DECLARE @Password_hash VARBINARY(64);
	SET @Password_hash = HASHBYTES('SHA2_512', CONCAT(@Salt, @MotDePasse, @Secret, @Salt));

	-- Ajout de l'utilisateur dans la DB avec le mot de passe hashé
	INSERT INTO [dbo].[Utilisateurs] ([Email], [DateDeNaissance], [MotDePasse], [Salt], [Administrateur],[Actif])
	 OUTPUT [inserted].[Id]
	 VALUES (@Email, @DateDeNaissance,  @Password_hash, @Salt, @administrateur,@actif);
END
