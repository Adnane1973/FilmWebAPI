﻿CREATE PROCEDURE [dbo].[SupprimerCommentaire]
	@Id int
	
AS
	Begin
	delete from [Commentaires] where Id = @Id;
	End
