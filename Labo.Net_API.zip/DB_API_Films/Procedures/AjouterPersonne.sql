﻿CREATE PROCEDURE [dbo].[AjouterPersonne]
	@Nom nvarchar(50),
	@Prenom nvarchar(50)
AS

Begin
	Insert into [dbo].[Personnes] ([Nom],[Prenom])

	values(@Nom,@Prenom)

End
