﻿CREATE PROCEDURE [dbo].[AjouterFilm]
	@Titre NVARCHAR(50),
	@AnneeDeSortie int,
	@Resume nvarchar(1000),
	@IdScen int,@IdReal int
AS
	Begin
	Set nocount on

	Insert into [dbo].[Films] ([Titre],[AnneeDeSortie],[Resume],[ScenaristeID],[RealisateurID])

	Values(@Titre,@AnneeDeSortie,@Resume,@IdScen,@IdReal)


	End