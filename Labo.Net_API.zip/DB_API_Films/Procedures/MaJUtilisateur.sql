﻿CREATE PROCEDURE [dbo].[MaJUtilisateur]
	@Email nvarchar(250),
	@MotdePasse nvarchar(50),
	@DatedeNaissance nvarchar(50),
	@Id int

	As 

	Begin

	Update [dbo].[Utilisateurs]
	
	Set Email = @Email, MotdePasse = Convert (varBinary(64),@MotdePasse), 
	DatedeNaissance = @DatedeNaissance where Id = @Id;
	

	End