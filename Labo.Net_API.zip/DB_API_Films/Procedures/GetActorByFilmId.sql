﻿CREATE PROCEDURE [dbo].[GetActorByFilmId]
@FilmId int
AS
BEGIN
SELECT *
FROM Personnes p
JOIN Acteurs a ON p.Id = a.PersonneID
WHERE a.filmID = @FilmId
END