﻿CREATE PROCEDURE [dbo].[DesactiverUtilisateur]
	@Id int
AS
Begin

IF((SELECT Actif FROM [dbo].[Utilisateurs] where Id=@Id)=1)
Update [dbo].[Utilisateurs]
set Actif=0

else
Begin
update [dbo].[Utilisateurs]
Set Actif = 1 WHERE Id = @Id;
End
	
End