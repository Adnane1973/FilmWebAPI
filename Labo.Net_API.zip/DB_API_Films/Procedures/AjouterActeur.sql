﻿CREATE PROCEDURE [dbo].[AjouterActeur]
@PersonneID int, @FilmID int ,
@Role NVARCHAR (50)

As 
Begin
Set nocount on
Insert into [dbo].[Acteurs] ([personneID],[filmID],[Role])

Values (@PersonneID,@FilmID,@Role)

End