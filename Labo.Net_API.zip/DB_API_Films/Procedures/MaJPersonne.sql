﻿CREATE PROCEDURE [dbo].[MaJPersonne]
	@Nom nvarchar(50),
	@Prenom nvarchar(50)
AS
	Begin
	Update [dbo].[Personnes]

	Set Nom = @Nom,Prenom = @Prenom;

	End
