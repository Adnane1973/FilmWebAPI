﻿CREATE PROCEDURE [dbo].[AjouterCommentaire]
	@DateDeMiseEnLigne date,
	@contenu nvarchar(1000),
	@Id_film int,@Id_util int
AS
Set nocount on

	Begin

	Insert into [dbo].[Commentaires] ([DateDeMiseEnLigne],[contenu],[utilisateurID],[filmID])

	Values(@DateDeMiseEnLigne,@contenu,@Id_util,@Id_film)

	End
