﻿CREATE PROCEDURE [dbo].[MaJFilm]
	@Titre NVARCHAR(50),
	@AnneeDeSortie int, 
	@Resume NVARCHAR(1000)
AS
	
	Begin

	Update[dbo].[Films]

	Set Titre = @Titre, AnneeDeSortie = @AnneeDeSortie, [Resume] = @Resume;

	End
