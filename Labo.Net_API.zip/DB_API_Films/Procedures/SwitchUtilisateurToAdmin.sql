﻿CREATE PROCEDURE [dbo].[SwitchUtilisateurToAdmin]
	@Id int
AS
Begin

IF((SELECT Administrateur FROM [dbo].[Utilisateurs] WHERE Id = @Id) = 1)

	BEGIN
		UPDATE [dbo].[Utilisateurs] SET Administrateur = 0 WHERE Id = @Id
	END
	ELSE
	BEGIN
		UPDATE [dbo].[Utilisateurs] SET Administrateur = 1 WHERE Id = @Id
	END


End
