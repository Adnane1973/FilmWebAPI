﻿CREATE PROCEDURE [dbo].[MaJCommentaire]
	@contenu NVARCHAR(1000)

	as 
	Begin
	update [dbo].[Commentaires]

	Set contenu = @contenu;

	End
