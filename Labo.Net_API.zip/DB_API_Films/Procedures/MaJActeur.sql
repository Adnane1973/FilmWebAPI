﻿CREATE PROCEDURE [dbo].[MaJActeur]
	@PersonneId int,
	@FilmId int,
	@Role NVARCHAR(50)
AS
	Begin
	Update [dbo].[Acteurs]
	set [Role] = @Role where (personneID = @PersonneId  AND filmID = @FilmId)
	end

