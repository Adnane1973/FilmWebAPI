﻿CREATE TABLE [dbo].[Films]
(
	[Id] INT NOT NULL PRIMARY KEY Identity, 
    [Titre] NVARCHAR(50) NOT NULL, 
    [AnneeDeSortie] INT NULL, 
    [Resume] NVARCHAR(1000) NULL, 
    [ScenaristeID] INT NOT NULL, 
    [RealisateurID] INT NOT NULL, 
    CONSTRAINT [FK_Scenariste] FOREIGN KEY ([ScenaristeID]) REFERENCES [Personnes]([Id]), 
    CONSTRAINT [FK_Realisateur] FOREIGN KEY ([RealisateurID]) REFERENCES [Personnes]([Id])
)
