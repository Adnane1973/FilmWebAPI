﻿CREATE TABLE [dbo].[Personnes]
(
	[Id] INT NOT NULL PRIMARY KEY Identity, 
    [Nom] NVARCHAR(50) NOT NULL, 
    [Prenom] NVARCHAR(50) NOT NULL
)
