﻿CREATE TABLE [dbo].[Utilisateurs]
(
	[Id] INT NOT NULL PRIMARY KEY identity, 
    [Email] NVARCHAR(250) NOT NULL, 
    [MotdePasse] VARBINARY(64) NOT NULL, 
    [DatedeNaissance] NVARCHAR(50) NOT NULL, 
    [Administrateur] BIT NOT NULL, 
    [Actif] BIT NOT NULL, 
    [salt] NCHAR(100) NULL
)
