﻿CREATE TABLE [dbo].[Acteurs]
(
	[Id] INT NOT NULL PRIMARY KEY Identity, 
    [personneID] INT NOT NULL, 
    [filmID] INT NOT NULL, 
    [Role] NVARCHAR(50) NOT NULL, 
    CONSTRAINT [FK_Personnes] FOREIGN KEY ([personneID]) REFERENCES [Personnes]([Id]), 
    CONSTRAINT [FK_Film] FOREIGN KEY ([filmID]) REFERENCES [Films]([Id])
)
