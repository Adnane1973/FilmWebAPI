﻿CREATE TABLE [dbo].[Commentaires]
(
	[Id] INT NOT NULL PRIMARY KEY Identity, 
    [DateDeMiseEnLigne] DATE NOT NULL DEFAULT getdate(), 
    [utilisateurID] INT NOT NULL, 
    [filmID] INT NOT NULL, 
    [contenu] NVARCHAR(1000) NOT NULL, 
    CONSTRAINT [FK_utilisateur] FOREIGN KEY ([utilisateurID]) REFERENCES [Utilisateurs]([Id]), 
    CONSTRAINT [FK_Films] FOREIGN KEY ([filmID]) REFERENCES [Films]([Id])
)
