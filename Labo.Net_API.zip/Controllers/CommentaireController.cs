﻿using API_Films_DAL.Entities;
using API_Films_DAL.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Labo.Net_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentaireController : ControllerBase
    {
        private CommentaireRepos _CommentaireRepos { get; }

        public CommentaireController(CommentaireRepos commentaireRepos)
        {
            _CommentaireRepos = commentaireRepos;
        }
        // GET: api/<CommentaireController>
        [HttpGet]
        //[Authorize("Administrateur")]
        public IActionResult list()
        {
            IEnumerable<CommentaireEntity> commentaires = _CommentaireRepos.GetAll();

            return Ok(commentaires);
        }

        // GET api/<CommentaireController>/5
        [HttpGet("{id}")]
        //[Authorize("Utilisateur")]
        public IActionResult Get(int id)
        {
            return Ok(_CommentaireRepos.Get(id));
        }
        [HttpPost]
        //[Authorize("Utilisateur")]
        public IActionResult AddMessage(CommentaireEntity commentaire)
        {
            if (commentaire is null || !ModelState.IsValid)
                return BadRequest();


            _CommentaireRepos.Insert(commentaire);
                return Ok(); // statut 204
        }

        [HttpDelete("{Id}")]
        //[Authorize("Administrateur")]
        public IActionResult Delete(int Id)
        {
            if (_CommentaireRepos.Get(Id) == null)
                return BadRequest();

            return Ok(_CommentaireRepos.Delete(Id));
        }

        [HttpPut]
        //[Authorize("Utilisateur")]
        public IActionResult Update(CommentaireEntity m)
        {
            if (_CommentaireRepos.Get(m.Id) == null)
                return BadRequest();

            return Ok(_CommentaireRepos.Update(m));
        }
       
    }
}
