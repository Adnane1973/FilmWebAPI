﻿using API_Films_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Tools;

namespace API_Films_DAL.Repositories
{
    public class PersonneRepos : RepositoryBase<int, PersonneEntity>
    { 
        public PersonneRepos() : base("Personnes", "Id") { }


    public override bool Delete(int id)
        {
            throw new NotImplementedException();
        }

        public override int Insert(PersonneEntity entity)
        {
            Command cmd = new Command("AjouterPersonne", true);
            cmd.AddParameter("@Nom", entity.Nom);
            cmd.AddParameter("@Prenom", entity.Prenom);

            return (int)Connection.ExecuteNonQuery(cmd);
        }

        public override bool Update(PersonneEntity data)
        {
            Command cmd = new Command("MaJPersonne", true);
            cmd.AddParameter("@Nom", data.Nom);
            cmd.AddParameter("@Prenom", data.Prenom);

            return Connection.ExecuteNonQuery(cmd) == 1;
        }

        protected override PersonneEntity Convert(IDataRecord reader)
        {
            return new PersonneEntity()
            {
                Id = (int)reader["Id"],
                Nom = reader["Nom"].ToString(),
                Prenom = reader["Prenom"].ToString()
            };

        }
    }
}
