﻿using API_Films_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Tools;

namespace API_Films_DAL.Repositories
{
    public class ActeurRepos:RepositoryBase<int,ActeurEntity>
    {
        public ActeurRepos() : base("Acteurs", "Id") { }

        public override bool Delete(int id)
        {
            throw new NotImplementedException();
        }

        public override int Insert(ActeurEntity entity)
        {
            Command cmd = new Command("AjouterActeur", true);
            cmd.AddParameter("@PersonneID", entity.PersonneId);
            cmd.AddParameter("@FilmID", entity.FilmId);
            cmd.AddParameter("@Role", entity.Role);
            return (int)Connection.ExecuteNonQuery(cmd);
        }

        public override bool Update(ActeurEntity data)
        {
            Command cmd = new Command("MaJActeur", true);
            cmd.AddParameter("@PersonneId", data.PersonneId);
            cmd.AddParameter("@FilmId", data.FilmId);
            cmd.AddParameter("@Role", data.Role);

            return Connection.ExecuteNonQuery(cmd) == 1;
        }

        public IEnumerable<Acteur> GetByFilmId(int id)
        {
            Command cmd = new Command("GetActorByFilmId", true);
            cmd.AddParameter("@FilmId", id);

            return Connection.ExecuteReader(cmd, ConvertActeur);
        }
        protected Acteur ConvertActeur(IDataRecord reader)
        {
            return new Acteur
            {
                Id = (int)reader["PersonneId"],
                Role = reader["Role"].ToString(),
                Nom = reader["Nom"].ToString(),
                Prenom = reader["Prenom"].ToString()
            };
        }

        protected override ActeurEntity Convert(IDataRecord reader)
        {
            return new ActeurEntity()
            {
                Id = (int)reader["Id"],
                PersonneId = (int)reader["PersonneId"],
                FilmId = (int)reader["FilmId"],
                Role = reader["Role"].ToString()
            };
        }
    }
}
