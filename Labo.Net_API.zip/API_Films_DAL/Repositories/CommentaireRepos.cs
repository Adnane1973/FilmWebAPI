﻿using API_Films_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Tools;

namespace API_Films_DAL.Repositories
{
    public class CommentaireRepos : RepositoryBase<int, CommentaireEntity>
    { 
        public CommentaireRepos() : base("Commentaires", "Id") { }

    
        public override bool Delete(int id)
        {
            Command cmd = new Command("SupprimerCommentaire", true);
            cmd.AddParameter("@Id", id);
            return Connection.ExecuteNonQuery(cmd)==1;
        }

        public override int Insert(CommentaireEntity entity)
        {
            Command cmd = new Command("AjouterCommentaire", true);
            cmd.AddParameter("@contenu", entity.Contenu);
            cmd.AddParameter("@DateDeMiseEnLigne", entity.DateDeMiseEnLigne);
            cmd.AddParameter("@Id_film", entity.FilmId);
            cmd.AddParameter("@Id_Util", entity.UtilisateurId);

            return (int)Connection.ExecuteScalar(cmd);
        }

        public override bool Update(CommentaireEntity data)
        {
            Command cmd = new Command("MaJCommentaire", true);
            cmd.AddParameter("@contenu", data.Contenu);

            return Connection.ExecuteNonQuery(cmd) == 1;
        }

        protected override CommentaireEntity Convert(IDataRecord reader)
        {
            return new CommentaireEntity()
            {
                Id = (int)reader["Id"],
                Contenu = reader["contenu"].ToString(),
                DateDeMiseEnLigne = (DateTime)reader["DateDeMiseEnLigne"],
                UtilisateurId = (int)reader["UtilisateurId"],
                FilmId = (int)reader["FilmId"]
            };
        }
    }
}
