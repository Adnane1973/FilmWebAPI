﻿using API_Films_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Tools;

namespace API_Films_DAL.Repositories
{
    public class UtilisateurRepos : RepositoryBase<int, UtilisateurEntity>
    {
        public UtilisateurRepos(): base("V_Utilisateur","Id")
            {}
       

        protected override UtilisateurEntity Convert(IDataRecord reader)
        {
            return new UtilisateurEntity()
            {
                Id = (int)reader["Id"],
                Email = reader["Email"].ToString(),
                DateDeNaissance = reader["DatedeNaissance"].ToString(),
                MotDePasse = null,
                Administrateur= (bool)reader["Administrateur"],
                Actif = (bool)reader["Actif"]
            };
        }

        public override int Insert(UtilisateurEntity entity)
        {
            Command cmd = new Command("AjouterUtilisateur", true);
            cmd.AddParameter("@email", entity.Email);
            cmd.AddParameter("@DateDeNaissance", entity.DateDeNaissance);
            cmd.AddParameter("@MotDePasse", entity.MotDePasse);
            cmd.AddParameter("@Administrateur", 0);
            cmd.AddParameter("@Actif", 1);


            return (int)Connection.ExecuteScalar(cmd);
        }

        public bool Desactiver(int Id)
        {
            Command cmd = new Command("DesactiverUtilisateur", true);
            cmd.AddParameter("@Id", Id);


            return Connection.ExecuteNonQuery(cmd) == 1;
        }

        public override bool Update(UtilisateurEntity data)
        {
            Command cmd = new Command("MaJUtilisateur", true);
            cmd.AddParameter("@Id", data.Id);
            cmd.AddParameter("@Email", data.Email);
            cmd.AddParameter("@MotDePasse", data.MotDePasse);
            cmd.AddParameter("@DateDeNaissance", data.DateDeNaissance);

            return Connection.ExecuteNonQuery(cmd) == 1;
        }
        public bool SwitchToAdmin(int Id)
        {
            Command cmd = new Command("SwitchUtilisateurToAdmin", true);
            cmd.AddParameter("@Id", Id);


            return Connection.ExecuteNonQuery(cmd) == 1;
        }
        public UtilisateurEntity Login(string email, string motdepasse)
        {
            Command cmd = new Command("ConnecterUtilisateur", true);
            cmd.AddParameter("@Email", email);
            cmd.AddParameter("@MotDePasse", motdepasse);

            return Connection.ExecuteReader(cmd, Convert).SingleOrDefault();
        }


        public override bool Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
        

       
    }
   

    

  
 

   

