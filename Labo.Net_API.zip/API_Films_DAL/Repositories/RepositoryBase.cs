﻿using API_Films_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Tools;

namespace API_Films_DAL.Repositories
{
    public abstract class RepositoryBase<TKey, TEntity> : IRepository<TKey, TEntity>
         where TEntity : IEntity<TKey>
    {
        protected Connection Connection { get; }
        protected string TableName { get; }
        protected string IdName { get; }

        public RepositoryBase(string tableName, string idName = "Id")
        {
            //Connection = new Connection(SqlClientFactory.Instance, @"Data Source=FORMA-VDI1705\TFTIC;Initial Catalog=DB_API_Films;User ID=sa;Password=tftic@2012;");
            Connection = new Connection(SqlClientFactory.Instance, @"Server=tcp:adnaneazure.database.windows.net,1433;Initial Catalog=DB_API_Films;Persist Security Info=False;User ID=Adnane;Password=Chahine1810;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");


            TableName = tableName;
            IdName = idName;
        }

        protected abstract TEntity Convert(IDataRecord reader);

        public virtual IEnumerable<TEntity> GetAll()
        {
            Command cmd = new Command("SELECT * FROM [" + TableName + "]");

            return Connection.ExecuteReader(cmd, Convert);
        }
        public virtual TEntity Get(TKey id)
        {
            Command cmd = new Command("SELECT * FROM [" + TableName + "] " +
                                      "WHERE " + IdName + " = @Id");
            cmd.AddParameter("@Id", id);

            return Connection.ExecuteReader(cmd, Convert).SingleOrDefault();
        }


        public abstract TKey Insert(TEntity entity);
        public abstract bool Update(TEntity data);
        public abstract bool Delete(TKey id);
    }
}
