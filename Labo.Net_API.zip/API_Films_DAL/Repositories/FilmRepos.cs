﻿using API_Films_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Tools;

namespace API_Films_DAL.Repositories
{
    public class FilmRepos: RepositoryBase<int, FilmEntity>
    {
        public FilmRepos() : base("Films", "Id") { }
    
public override bool Delete(int id)
        {
            throw new NotImplementedException();
        }

        public override int Insert(FilmEntity entity)
        {
            Command cmd = new Command("AjouterFilm", true);
            cmd.AddParameter("@Titre", entity.Titre);
            cmd.AddParameter("@AnneeDeSortie", entity.AnneeDeSortie);
            cmd.AddParameter("@Resume", entity.Resume);
            cmd.AddParameter("@IdScen", entity.ScenaristeID);
            cmd.AddParameter("@IdReal", entity.RealisateurID);

            return (int)Connection.ExecuteScalar(cmd);

        }

        public override bool Update(FilmEntity data)
        {
            Command cmd = new Command("MaJFilm", true);
            cmd.AddParameter("@Titre", data.Titre);
            cmd.AddParameter("@AnnéeDeSortie", data.AnneeDeSortie);
            cmd.AddParameter("@Resume", data.Resume);

            return Connection.ExecuteNonQuery(cmd) == 1;
        }

        protected override FilmEntity Convert(IDataRecord reader)
        {
            return new FilmEntity()
            {
                Id = (int)reader["Id"],
                Titre = reader["Titre"].ToString(),
                Resume = reader["Resume"].ToString(),
                AnneeDeSortie = (int)reader["AnneeDeSortie"],
                ScenaristeID = (int)reader["ScenaristeID"],
                RealisateurID = (int)reader["RealisateurID"]
            };
        }
    }
}
