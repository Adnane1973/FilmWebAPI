﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API_Films_DAL.Entities
{
   public class FilmEntity:IEntity<int>
    {
        public int Id { get; set; }
        public string Titre { get; set; }
        public string Resume { get; set; }
        public int AnneeDeSortie { get; set; }
        public int ScenaristeID { get; set; }
        public int RealisateurID { get; set; }

    }
}
