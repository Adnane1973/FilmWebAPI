﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API_Films_DAL.Entities
{
    public interface IEntity<Tkey>
    {
        public Tkey Id { get; set; }
    }
}
