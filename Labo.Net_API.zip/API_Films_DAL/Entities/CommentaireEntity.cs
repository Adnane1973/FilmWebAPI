﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API_Films_DAL.Entities
{
   public class CommentaireEntity: IEntity<int>
    {
        public int Id { get; set; }
        public string Contenu { get; set; }
        public DateTime DateDeMiseEnLigne { get; set; }
        public int UtilisateurId { get; set; }
        public int FilmId { get; set; }
    }
}
