﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API_Films_DAL.Entities
{
   public class PersonneEntity:IEntity<int>
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }

    }
}
