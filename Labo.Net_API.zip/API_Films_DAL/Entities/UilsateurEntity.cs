﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API_Films_DAL.Entities
{
    public class UtilisateurEntity: IEntity<int>
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string MotDePasse { get; set; }
        public string DateDeNaissance  { get; set; }
        public bool Administrateur { get; set; }
        public bool Actif { get; set; }

    }
}
