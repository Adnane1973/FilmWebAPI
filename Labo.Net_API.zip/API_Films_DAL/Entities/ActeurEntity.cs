﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API_Films_DAL.Entities
{
   public class ActeurEntity:IEntity<int>
    {
        public int Id { get; set; }
        public int PersonneId { get; set; }
        public int FilmId { get; set; }
        public string Role { get; set; }
    }
}
