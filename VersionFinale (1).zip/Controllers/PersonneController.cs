﻿using API_Films_DAL.Entities;
using API_Films_DAL.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Labo.Net_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonneController : ControllerBase
    {
        private PersonneRepos _PersonneRepos { get; }

        public PersonneController(PersonneRepos personneRepos)
        {
           _PersonneRepos = personneRepos;
        }

        // GET: api/<PersonneController>
        [HttpGet]
        //[Authorize("Administrateur")]
        public IActionResult List()
        {
            IEnumerable<PersonneEntity> personnes = _PersonneRepos.GetAll();
            return Ok(personnes);
        }

        // GET api/<PersonneController>/5
        [HttpGet("{id}")]
        //[Authorize("Administrateur")]
        public IActionResult Get(int id)
        {
            return Ok(_PersonneRepos.Get(id));
        }

        // POST api/<PersonneController>
        [HttpPost]
        //[Authorize("Administrateur")]
        public IActionResult AjouterPersonne(PersonneEntity personne)
        {
            
                if (personne is null || !ModelState.IsValid)
                    return BadRequest();
                _PersonneRepos.Insert(personne);
                    return Ok(); // statut 204
            
        }

        // PUT api/<PersonneController>/5
        [HttpPut("{id}")]
        //[Authorize("Administrateur")]
        public IActionResult ModifierPersonne(PersonneEntity p)
        {
            if (_PersonneRepos.Get(p.Id) == null)
                return BadRequest();

            return Ok(_PersonneRepos.Update(p));
        }

        
    }
}
