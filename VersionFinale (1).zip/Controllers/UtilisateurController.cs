﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API_Films_DAL.Entities;
using API_Films_DAL.Repositories;
using Labo.Net_API.Models;
using Microsoft.AspNetCore.Authorization;
using Labo.Net_API.TokenJWT;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Labo.Net_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilisateurController : ControllerBase
    {
        private UtilisateurRepos _UtilisateurRepos { get; }
        private TokenManager _TokenManager { get; }

        public UtilisateurController(UtilisateurRepos utilisateurRepos,TokenManager tokenManager)
        {
            _UtilisateurRepos = utilisateurRepos;
            _TokenManager = tokenManager;
        }
        [HttpPost]
        [Route("Enregistrer")]
        [AllowAnonymous]
        public IActionResult Enregistrer(EnregistrerUtilisateur enregistrerUtilisateur)
        {
            if (enregistrerUtilisateur is null || !ModelState.IsValid)
                return BadRequest();

            int id = _UtilisateurRepos.Insert(new API_Films_DAL.Entities.UtilisateurEntity()
            {
                Email = enregistrerUtilisateur.Email,
                MotDePasse = enregistrerUtilisateur.MotDePasse
            });

            /*Generate Token
            return Ok(new
            {
                token = TokenManager.GenerateJWT(id, enregistrerUtilisateur.Email)
            });*/

            return Ok();
        }

        [HttpPost]
        [Route("SeConnecter")]
        
        public IActionResult Login(ConnecterUtilisateur connecterUtilisateur)
        {
            if (connecterUtilisateur is null || !ModelState.IsValid)
                return BadRequest();

            UtilisateurEntity utilisateur = _UtilisateurRepos.Login(connecterUtilisateur.Email, connecterUtilisateur.MotDePasse);

            if (utilisateur is null)
                return new ForbidResult();

            return Ok(new TokenManager().GenerateJWT(utilisateur));
        }

        // GET: api/<UtilisateurController>
        [HttpGet]
        [Authorize("utilisateur")]
        public IActionResult GetAll()
        {
            return Ok(_UtilisateurRepos.GetAll());
        }

        // GET api/<UtilisateurController>/5
        [HttpGet("{id}")]
        [Authorize("utilisateur")]
        public IActionResult Get(int id)
        {
            return Ok(_UtilisateurRepos.Get(id));
        }

        // PUT api/<UtilisateurController>/5
        [HttpPut("desactiver/{id}")]
        [Authorize("Administrateur")]
        public IActionResult ActiverDesactiver(int id)
        {
            return Ok(_UtilisateurRepos.Desactiver(id));
        }

        [HttpPut("maj")]
        [Authorize("utilisateur")]
        public IActionResult Update(UtilisateurEntity utilisateur)
        {
            return Ok(_UtilisateurRepos.Update(utilisateur));
        }

        [HttpPut("switchToAdmin/{id}")]
        [Authorize("administrateur")]
        public IActionResult SwitchAdmin(int id)
        {
            return Ok(_UtilisateurRepos.SwitchToAdmin(id));
        }
        // DELETE api/<UtilisateurController>/5
        // [HttpDelete("{id}")]
        // public void Delete(int id)
        // {
        //}
    }
}
