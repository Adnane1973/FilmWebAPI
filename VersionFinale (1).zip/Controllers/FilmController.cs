﻿using API_Films_DAL.Entities;
using API_Films_DAL.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Labo.Net_API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class FilmController : ControllerBase
    {
        private FilmRepos _FilmRepos { get; }

        public FilmController(FilmRepos filmRepos)
        {
            _FilmRepos = filmRepos;
        }
        // GET: api/<FilmController>
        [HttpGet]
        [AllowAnonymous]
        public IActionResult List()
        {
            IEnumerable<FilmEntity> films = _FilmRepos.GetAll();
            return Ok(films);
        }

        // GET api/<FilmController>/5
        [Authorize("utilisateur")]
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            return Ok(_FilmRepos.Get(id));
        }

        // POST api/<FilmController>
        [HttpPost]
        [Authorize("administrateur")]
        public IActionResult AjouterFilm(FilmEntity film)
        {
            if (film is null || !ModelState.IsValid)
                return BadRequest();


            _FilmRepos.Insert(film);
            return Ok(); // statut 204
        }

        // PUT api/<FilmController>/5
        [HttpPut("{id}")]
        [Authorize("administrateur")]
        public IActionResult ModifierFilm(FilmEntity f)
        {
            if (_FilmRepos.Get(f.Id) == null)
                return BadRequest();

            return Ok(_FilmRepos.Update(f));
        }

        
    }
}
