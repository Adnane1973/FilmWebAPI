﻿using API_Films_DAL.Entities;
using API_Films_DAL.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Labo.Net_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActeurController : ControllerBase
    {
        private ActeurRepos _ActeurRepos { get; }

        public ActeurController(ActeurRepos acteurRepos) 
        {
            _ActeurRepos = acteurRepos;
        }
       
        // GET api/<ActeurController>/5
        [HttpGet("{id}")]
        public IActionResult ListByFilmId(int id)
        {
            IEnumerable<Acteur> acteurs = _ActeurRepos.GetByFilmId(id);
            return Ok(acteurs);
        }

        // POST api/<ActeurController>
        [HttpPost]
        [Authorize("Administrateur")]
        public IActionResult AjouterActeur(ActeurEntity acteur)
        {
            if (acteur is null || !ModelState.IsValid)
                return BadRequest();
            _ActeurRepos.Insert(acteur);
                return Ok();
        }

        // PUT api/<ActeurController>/5
        [HttpPut("{id}")]
        [Authorize("Administrateur")]
        public IActionResult ModifierActeur(ActeurEntity a )
        {
            if (_ActeurRepos.Get(a.Id) == null)
                return BadRequest();

            return Ok(_ActeurRepos.Update(a));
        }

       
    }
}
