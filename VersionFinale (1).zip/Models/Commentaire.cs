﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Labo.Net_API.Models
{
    public class Commentaire
    {
        [Required]
        public string Contenu { get; set; }

        [Required]
        public int FilmId { get; set; }

        [Required]
        public int UtilisateurId { get; set; }

    }
}
