﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Labo.Net_API.Models
{
    public class Film
    {
        [Required]
        public string Titre { get; set; }
        [Required]
        public string Resume { get; set; }
        [Required]
        public int AnneeDeSortie { get; set; }
        [Required]
        public int ScenaristeID { get; set; }
        [Required]
        public int RealisateurID { get; set; }
    }
}
