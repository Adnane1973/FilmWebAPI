import { Component, OnInit } from '@angular/core';
import { NbMenuItem } from '@nebular/theme';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {
  
  Urls : NbMenuItem[];

  constructor() { }

  ngOnInit(): void {
    this.Urls= [
      { link : '/home', title : 'Home', icon :'home-outline'},
      {link:'/Component/utilisateur-list',title:'Utilisateurs',icon:'people-outline'},
      {link:'/Component/personne',title:'Scénariste/Rélisateur/Acteur',icon:'person-outline'},
      {link:'/Component/film',title:'Films',icon:'film-outline'},
      {link:'/Component/commentaire',title:'Commentaires',icon:'message-circle-outline'},
    ]
  }

}
