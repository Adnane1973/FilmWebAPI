import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthentificationService, User } from 'src/app/Services/authentification.service';
import { UtilServiceService } from '../utilisateur/util-service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  statusConnexion : boolean;
    email : string

  //statusSubscription : Subscription

  constructor(
   
    private _auth : AuthentificationService,
    private _router : Router
  ) { }

  ngOnInit(): void {
   // this.statusSubscription = this._auth.subConnexion.subscribe((status : boolean) => this.statusConnexion = status)
    this._auth.subConnexion.subscribe((status : boolean) =>  {
      this.statusConnexion = status,
      this.email = localStorage.getItem('email')
    })
    this._auth.emitConnexion()
  }

  login() {
    this._router.navigate(['Component/utilisateur/login'])
  }

  logout() {
    this._auth.disconnect()
  }

  register() {
    this._router.navigate(['Component/utilisateur/register'])
  }
}
