import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-film-add',
  templateUrl: './film-add.component.html',
  styleUrls: ['./film-add.component.scss']
})
export class FilmAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
