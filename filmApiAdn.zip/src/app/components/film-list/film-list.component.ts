import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { Commentaire, Film, FilmServiceService } from 'src/app/Services/film-service.service';

@Component({
  selector: 'app-film-list',
  templateUrl: './film-list.component.html',
  styleUrls: ['./film-list.component.scss']
})
export class FilmListComponent implements OnInit {
  _filmser: any;
 
  
  
  constructor(
    _httpClient:HttpClient,
    _filmser:FilmServiceService,
    ) {
   }

  ngOnInit(): void {
  }
  getFilmList() : Observable<Film[]> {
      return this._filmser.getAll("http://localhost:52838/api/film")
     
    }
}
