import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-film-update',
  templateUrl: './film-update.component.html',
  styleUrls: ['./film-update.component.scss']
})
export class FilmUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
