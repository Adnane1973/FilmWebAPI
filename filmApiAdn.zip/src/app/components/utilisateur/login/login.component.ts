import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { subscribeOn } from 'rxjs/operators';
import { login } from 'src/app/models/login.model';
import { AuthentificationService } from 'src/app/Services/authentification.service';
import { UtilServiceService } from '../util-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  myFormGroup : FormGroup

  constructor(
    private _builder : FormBuilder,
    private _userSer : AuthentificationService
  ) { }

  ngOnInit(): void {
    this.myFormGroup = this._builder.group({
      email : [null, [Validators.required, Validators.email]],
      password : [null, Validators.required]
    })
  }

  submitForm(){
    let newUser = new login()
    newUser.email = this.myFormGroup.value['email']
    newUser.motDePasse = this.myFormGroup.value['password']
    
    this._userSer.connect(newUser.email,newUser.motDePasse)
  }

}