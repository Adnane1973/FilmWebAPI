import { Component, OnInit } from '@angular/core';
import { NbToastrService } from '@nebular/theme';
import { AuthentificationService, User } from 'src/app/Services/authentification.service';
import { UtilServiceService,utilisateur } from './util-service.service';
const url= 'http://localhost:52838/api/Utilisateur';

@Component({
  selector: 'app-utilisateur',
  templateUrl: './utilisateur-list.component.html',
  styleUrls: ['./utilisateur-list.component.scss']
})
export class UtilisateurListComponent implements OnInit {

  Utilisateurs?:utilisateur[]
  CurrentUser?:utilisateur
  CurrentIndex =-1
  role:string = '';
  errorMessage:string

  constructor(
   
    private _toast : NbToastrService,
    private _utilser:UtilServiceService
    ) { }

  ngOnInit(): void {
    this.loadList()
  }

loadList(): void {
  this._utilser.getAll().subscribe(
    (dataFromService : utilisateur[]) =>  {
      this.Utilisateurs = dataFromService
      this._toast.success("Liste des utilisateurs chargée avec succès", "", {duration : 5000})
    console.log(this.Utilisateurs)},

    error => this.errorMessage = error.message
  ); }
  

refreshList(): void {
  this.loadList();
  this.CurrentUser = undefined;
  this.CurrentIndex =-1;
}
setActiveUser(user:utilisateur,index:number): void{
  console.log(user)
  this.CurrentUser=user;
  this.CurrentIndex=index;
}

}
