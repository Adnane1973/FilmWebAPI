import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NbToastrService } from '@nebular/theme';
import { Observable } from 'rxjs';
import { login } from 'src/app/models/login.model';
import { NewUser } from 'src/app/models/newUser.model';

 

@Injectable({
  providedIn: 'root'
})
export class UtilServiceService {
  url= 'http://localhost:52838/api/Utilisateur';
  constructor(
    private _client : HttpClient,
    private _toast : NbToastrService,
    private _router : Router
  ) { }

  register(newUser : NewUser) {
    this._client.post("http://localhost:52838/api/Utilisateur/Enregistrer", newUser).subscribe(
      () => {
        console.log("Utilisateur enregistré")
        this._toast.success("Enregistrement effectué avec succès", "Bienvenue", {duration : 5000})
        this._router.navigate(['/component/utilisateur'])
    },
      (error) => console.log(error)
    )

  }
  getAll() : Observable<utilisateur[]> {
    return this._client.get<utilisateur[]>(this.url)
  }

  getUser(id:number) : Observable<utilisateur> {
    return this._client.get<utilisateur>(this.url+"/"+id)
  }
  

  updateMaj(id: number, data: utilisateur): Observable<utilisateur> {
    return this._client.put<utilisateur>(this.url+'/maj/'+id, data);
  }
  updateSwitchAdmin(id: number,data:utilisateur): Observable<utilisateur> {
    return this._client.put<utilisateur>(this.url+'/switchToAdmin/'+id ,data);
  }
  updateDesactivate(id: number, data: utilisateur): Observable<utilisateur> {
    return this._client.put<utilisateur>(this.url+'/desactiver/'+id ,data);
  }

 
}
export class utilisateur {
  id: number;
  email: string;
  token: string;
  Administrateur: boolean;
  Actif:boolean;
}