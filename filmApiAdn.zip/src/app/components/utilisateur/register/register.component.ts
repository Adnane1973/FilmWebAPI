import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { NewUser } from 'src/app/models/newUser.model';
import { User } from 'src/app/Services/authentification.service';
import { UtilServiceService } from '../util-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  myFormGroup : FormGroup

  constructor(
    private _builder : FormBuilder,
    private _userSer : UtilServiceService
  ) { }

  ngOnInit(): void {
    this.myFormGroup = this._builder.group({
      email : [null, [Validators.required, Validators.email]],
      password : [null,[this.Min6char(), Validators.required]],
      dateNaissance : [null, [Validators.required,this.DateValid()]]
    })
  }
  Min6char() : ValidatorFn | null {
    return (control : FormControl) => {
      let myValue : string = control.value
      if(control.value == null) return null;
      if(myValue.length < 6) return {TropCourtError : "Le champ password doit contenir au moins 6 caractères"}
      return null;
    }
  }
  DateValid() : ValidatorFn | null {
    return (control : AbstractControl) => {
        let maDate : Date = new Date(control.value)
        if(control.value == null) return null;
        if(maDate.getFullYear() <= (new Date().getFullYear() -18)) {
            return null;
        }
        else return {dateError : 'Vous êtes trop jeune'}
    }
}

  submitForm(){
    let newUser = new NewUser()
    newUser.email = this.myFormGroup.value['email']
    newUser.motDePasse = this.myFormGroup.value['password']
    newUser.dateDeNaissance = this.myFormGroup.value['dateNaissance']

    this._userSer.register(newUser)
  }

}
