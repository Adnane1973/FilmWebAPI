import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { utilisateur, UtilServiceService } from '../utilisateur/util-service.service';

@Component({
  selector: 'app-utilisateur-details',
  templateUrl: './utilisateur-details.component.html',
  styleUrls: ['./utilisateur-details.component.scss']
})
export class UtilisateurDetailsComponent implements OnInit {

  currentUtilisateur: utilisateur = new utilisateur()
 
  constructor(
   // private _builder: FormBuilder,
    private userserv:UtilServiceService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    
    this.getUtil(this.route.snapshot.params['id']);
  }

  getUtil(id: number): void {
    console.log(id)
    this.userserv.getUser(id)
      .subscribe(
        (data : utilisateur) => {
          this.currentUtilisateur = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }
  updateAdmin(id :number): void {
     (data:utilisateur) => {
      data.id=this.currentUtilisateur.id;
      
    };

    this.userserv.updateSwitchAdmin(this.currentUtilisateur.id,this.currentUtilisateur)
      .subscribe(
        response => {
          this.currentUtilisateur.Administrateur=this.currentUtilisateur.Administrateur;
          console.log(response);
          
        },
        error => {
          console.log(error);
        });
  }
  updateActif(actif: boolean): void {
    const data = {
      email: this.currentUtilisateur.email,
            Actif: actif
    };

    this.userserv.updateDesactivate(this.currentUtilisateur.id,this.currentUtilisateur)
      .subscribe(
        response => {
          this.currentUtilisateur.Actif = actif;
          console.log(response);
          
        },
        error => {
          console.log(error);
        });
  }
    updateUtil(): void {
    this.userserv.updateMaj(this.currentUtilisateur.id, this.currentUtilisateur)
      .subscribe(
        (data : utilisateur) => {
           data = this.currentUtilisateur;
          console.log(this.currentUtilisateur);
        },
        error => {
          console.log(error);
        });
  }

  
}