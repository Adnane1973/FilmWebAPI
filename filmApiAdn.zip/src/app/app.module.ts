import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NbThemeModule, NbLayoutModule, NbCardModule, NbDialogModule, NbInputModule, NbListModule, NbMenuModule, NbSidebarModule, NbToastrModule, NbButtonModule } from '@nebular/theme';
import { NbEvaIconsModule } from '@nebular/eva-icons';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';
import { PersonneComponent } from './Components/personne/personne.component';


import { CommentaireComponent } from './Components/commentaire/commentaire.component';
import { RegisterComponent } from './components/utilisateur/register/register.component';
import { LoginComponent } from './components/utilisateur/login/login.component';
import { HeaderComponent } from './components/header/header.component';
import { TokenInterceptInterceptor } from './Services/token-intercept.interceptor';
import { UtilisateurDetailsComponent } from './components/utilisateur-details/utilisateur-details.component';
import { UtilisateurListComponent } from './components/utilisateur/utilisateur-list.component';
import { FilmAddComponent } from './components/film-add/film-add.component';
import { FilmUpdateComponent } from './components/film-update/film-update.component';
import { FilmDetailsComponent } from './components/film-details/film-details.component';
import { FilmListComponent } from './components/film-list/film-list.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavComponent,
    PersonneComponent,
    UtilisateurListComponent,
    UtilisateurDetailsComponent,
    FilmListComponent,
    CommentaireComponent,
    RegisterComponent,
    LoginComponent,
    HeaderComponent,
    FilmAddComponent,
    FilmUpdateComponent,
    FilmDetailsComponent,
    FilmListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    NbThemeModule.forRoot({ name: 'cosmic' }),
    NbLayoutModule,
    NbEvaIconsModule,
    NbButtonModule,
    NbCardModule,
    NbInputModule,
    NbListModule,
    FormsModule,
    ReactiveFormsModule,
    NbSidebarModule.forRoot(),
    NbMenuModule.forRoot(),
    NbToastrModule.forRoot(),
    NbDialogModule.forRoot(),
    HttpClientModule
  ],
  providers: [   
  {​​​​​ provide :HTTP_INTERCEPTORS, useClass:TokenInterceptInterceptor, multi :true}​​​​​
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
