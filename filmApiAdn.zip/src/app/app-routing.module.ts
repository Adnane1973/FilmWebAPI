import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommentaireComponent } from './Components/commentaire/commentaire.component';

import { PersonneComponent } from './Components/personne/personne.component';
import { LoginComponent } from './components/utilisateur/login/login.component';
import { RegisterComponent } from './components/utilisateur/register/register.component';

import { HomeComponent } from './home/home.component';
import { UtilisateurListComponent } from './components/utilisateur/utilisateur-list.component';
import { UtilisateurDetailsComponent } from './components/utilisateur-details/utilisateur-details.component';
import { FilmAddComponent } from './components/film-add/film-add.component';
import { FilmUpdateComponent } from './components/film-update/film-update.component';
import { FilmDetailsComponent } from './components/film-details/film-details.component';
import { FilmListComponent } from './components/film-list/film-list.component';

const routes: Routes = [
  { path : 'home', component : HomeComponent},
  { path : 'Component/utilisateur-list', component : UtilisateurListComponent},
  { path : 'utilisateur-details/:id', component : UtilisateurDetailsComponent},
  { path : 'Component/utilisateur/register', component : RegisterComponent},
  { path : 'Component/utilisateur/login', component : LoginComponent},
  { path : 'Component/personne', component : PersonneComponent},
  { path : 'Component/film-details/:id', component : FilmDetailsComponent},
  { path : 'Component/film-Update/:id', component : FilmUpdateComponent},
  { path : 'Component/film-Add', component : FilmAddComponent},
  { path : 'Component/film-list', component : FilmListComponent},
  { path : 'Component/commentaire', component : CommentaireComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
