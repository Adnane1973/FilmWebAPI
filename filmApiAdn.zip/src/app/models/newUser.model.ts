export class NewUser {
    
        email: string;
        motDePasse: string;
        dateDeNaissance: Date;
      

}