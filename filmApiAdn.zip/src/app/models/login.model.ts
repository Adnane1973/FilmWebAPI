export class login {
    
    email: string;
    motDePasse: string;
}