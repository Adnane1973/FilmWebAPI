import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NbToastrService } from '@nebular/theme';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FilmServiceService {
  url= 'http://localhost:52838/api/Film';
  constructor(
    private _client:HttpClient,
    private _toast:NbToastrService,
    private router: Router
  ) {

   }
   getAll() : Observable<Film[]> {
    return this._client.get<Film[]>(this.url)
  }

  getFilm(id:number) : Observable<Film> {
    return this._client.get<Film>(this.url+"/"+id)
  }
  
  updateFilm(id: number, data: Film): Observable<Film> {
    return this._client.put<Film>(this.url+'/'+id, data);
  }
    }

   export class Film {
  id : number;
  title : string;
  description : string;
  commentaires? : Commentaire[];
}

export class Commentaire {
  contenu : string;
  filmId : number;
  utilisateurId : number;
}


