import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NbToastrService } from '@nebular/theme';
import { Observable, Subject } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import jwt_decode from 'jwt-decode'
import { Router } from '@angular/router';

const url = 'http://localhost:52838/api/Utilisateur/';

@Injectable({
  providedIn: 'root'
})


export class AuthentificationService {

 IsConnected:boolean=false;
 subConnexion : Subject<boolean> = new Subject<boolean>()
  currentUser : User

  // ExempleConso(id : number) {

  //   // Type entre <> à ne spécifier qu'en cas de contenu retourné par l'api
  //   this._httpClient.get<Film[]>(this.url)

  //   this._httpClient.post(this.url,
  //     {myProp : "content"}).subscribe(
  //       //exécution une fois que l'api à répondu (next/error/complete)
  //     )

  //   this._httpClient.put(this.url, 
  //     {myProp : "content"}).subscribe(
  //       //exécution une fois que l'api à répondu (next/error/complete)
  //     )

  //   this._httpClient.delete(this.url + id).subscribe(
  //     //exécution une fois que l'api à répondu (next/error/complete)
  //   )
  //   //un paramètre supplémentaire peut être ajouter (optionnel) pour spécifier des 
  //   //propiétés de header

  //   // {myProp : "content"} => peut être remplacé par un objet
  // }


  constructor(
    private _httpClient : HttpClient,
    private _toast : NbToastrService,
    private _router : Router
  ) { }
  emitConnexion() {
    this.subConnexion.next(this.IsConnected)
  }
  connect(email : string, password : string) {   
    
    this._httpClient.post("http://localhost:52838/api/Utilisateur/SeConnecter",       
    {email : email, motDePasse :password}, {responseType : "text"}
      ).subscribe((token ) => {
       
        localStorage.setItem('token', token)
        let decodedToken = jwt_decode(token)
        console.log(decodedToken);

        this.currentUser = new User()
        this.currentUser.Email = decodedToken['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress']
        localStorage.setItem('email', this.currentUser.Email)
        this.currentUser.Id = decodedToken['UtilisateurId']
        this.currentUser.Role = decodedToken['http://schemas.microsoft.com/ws/2008/06/identity/claims/role']
        this.currentUser.Actif= decodedToken['http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata']
        this._toast.success("Connexion réussie", "Bonjour", {duration : 5000})
        this.IsConnected = true
        this.emitConnexion()
        this._router.navigate(['Component/film'])
      },
        (error) => {this._toast.danger(error)}
       
      )
  }
  disconnect() {
    localStorage.removeItem('token')
    this.currentUser = null
    this.IsConnected = false
    this.emitConnexion()
  }

}

export class User {
  Id : any;
  Email : string;
  Role : string;
  Actif: string;
}




